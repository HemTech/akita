import {
  Component, Input, OnInit,OnChanges,
  ChangeDetectionStrategy, Output, EventEmitter
} from '@angular/core';
import { ID } from '@datorama/akita';
import { Observable } from 'rxjs';
import { Student } from '../state/student.model';
import { StudentQuery } from '../state/student.query';
@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class GridComponent implements OnInit,OnChanges  {
  @Input() students$: Observable<Array<Student>>;
  @Output() add: EventEmitter<void> = new EventEmitter<void>();
  @Output() edit: EventEmitter<ID> = new EventEmitter<ID>();
  @Output() delete: EventEmitter<ID> = new EventEmitter<ID>();

  constructor(private studentQuery: StudentQuery) { }

  ngOnInit() {
    
    this.students$.subscribe(d => console.log(d));

    
  }
ngOnChanges() {
    
   

    
  }
}
