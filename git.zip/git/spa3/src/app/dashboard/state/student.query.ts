import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { Student } from './student.model';
import { StudentState, StudentStore } from './student.store';
import { map } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class StudentQuery extends QueryEntity<StudentState, Student> {

   

    constructor(protected store: StudentStore) {
        super(store);
    }

   
}
