import { Injectable } from '@angular/core';
import { ID } from '@datorama/akita';
import { StudentStore } from './student.store';
import { StudentQuery } from './student.query';
import { StudentDataService } from './student-data.service';
import { Student } from './student.model';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(
    private studentDataService: StudentDataService,
    private studentStore: StudentStore,
    private studentQuery: StudentQuery
  ) { }

  getStudents(): Observable<Array<Student>> {
     const request = this.studentDataService.getStudents().pipe(
      tap(s => this.studentStore.set(s))
    );

     console.log(request);
     return request;
  }

  deleteStudent(id: ID) {
    this.studentStore.remove(id);
  }

  updateStudent(student: Student) {
     this.studentStore.add(student);
    this.studentStore.update(student.id, { ...student });
  }

  

}
