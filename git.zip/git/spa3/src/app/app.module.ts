import { BrowserModule } from '@angular/platform-browser';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './Components/dashboard/dashboard.component';
import { HomeComponent } from './Components/home/home.component';

// import { NgRedux, NgReduxModule } from '@angular-redux/store';
import { IAppState, rootReducer, INITIAL_STATE,store } from './Shared/store';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SetNameComponent } from './set-name/set-name.component';
import { GetNameComponent } from './get-name/get-name.component';
import { AkitaNgDevtools } from '@datorama/akita-ngdevtools';

import { environment } from '../environments/environment';




import { DashboardComponent as db } from './dashboard/dashboard.component';
import { GridComponent } from './dashboard/grid/grid.component';
import { FormComponent } from './dashboard/form/form.component';



@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    HomeComponent,
     SetNameComponent,
    GetNameComponent,
      db,
    GridComponent,
    FormComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  imports: [
  
    environment.production ? [] : AkitaNgDevtools.forRoot(),
    BrowserModule,
    AppRoutingModule,    
     FormsModule,
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 
  //  constructor (private ngRedux: NgRedux<IAppState>) {
  //       // ngRedux.configureStore(rootReducer, INITIAL_STATE);
  //       ngRedux.provideStore(store);
  //   }
    
  //    ngDoBootstrap() {
  //   }
}
