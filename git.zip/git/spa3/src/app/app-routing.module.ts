import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './Components/dashboard/dashboard.component';
import { HomeComponent } from './Components/home/home.component';
import { DashboardComponent as db } from './dashboard/dashboard.component';
const routes: Routes = [
  { path: 'spa3', redirectTo: 'spa3/home', pathMatch: 'full' }, 
  { path: 'spa3/home', component: HomeComponent },
  { path: 'spa3/dashboard1', component: DashboardComponent },
  { path: 'spa3/dashboard', component: db },
  
  { path: '**', component: HomeComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
