import { Component, OnInit } from '@angular/core';
// import { NgRedux, select } from '@angular-redux/store';
import { IAppState,REMOVE_ALL_TODOS,ADD_TODO } from './../../Shared/store';

import { Router } from '@angular/router';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
public username: string = "Name";
//  @select() todos;
//   @select() lastUpdate;
  // constructor(private ngRedux: NgRedux<IAppState>,private router: Router) { }
  constructor(private router: Router) { }

  ngOnInit() { 
    //  this.ngRedux.subscribe(() => {
    //   let state = this.ngRedux.getState();
    //   console.log("state : ",state);
    // });
   }
 public routeTo(event: any) {
    
    this.router.navigateByUrl('/spa3/userpreference');
  }



}
