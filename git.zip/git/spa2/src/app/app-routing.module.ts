import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './Components/home/home.component';
import { DashboardComponent } from './Components/dashboard/dashboard.component';
const routes: Routes = [
  { path: 'spa2', redirectTo: 'spa2/home', pathMatch: 'full' }, 
  { path: 'spa2/home', component: HomeComponent },
  { path: 'spa2/dashboard', component: DashboardComponent },
  { path: '**', component: HomeComponent }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
