import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
// import { NgRedux, select } from '@angular-redux/store';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  // @select() todos;
  // @select() lastUpdate;
 constructor(private router: Router) { }

  ngOnInit() {
  }
 public routeTo() {
    
    this.router.navigateByUrl('/spa2/dashboard');
  }

}
