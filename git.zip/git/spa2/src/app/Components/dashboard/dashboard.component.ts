import { Component, OnInit } from '@angular/core';
// import { NgRedux, select } from '@angular-redux/store';
import { IAppState,REMOVE_ALL_TODOS,ADD_TODO } from './../../Shared/store';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  // @select() todos;
  // @select() lastUpdate;
  // constructor(private ngRedux: NgRedux<IAppState>,
  // private router: Router) { }

  constructor(private router: Router) { }

  ngOnInit() {
  }
  clearTodos() {
    // this.ngRedux.dispatch({type: REMOVE_ALL_TODOS});
  }
  
  addTodos() {
    // this.ngRedux.dispatch({type: ADD_TODO,todo: {id: 1,description:"one",responsible: "nothing",
    // isCompleted: true }});
  }

  public routeTo() {
    
    this.router.navigateByUrl('/spa2/home');
  }

  
}
